import { Component, OnInit, ViewChild, ElementRef, ViewEncapsulation } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog, MatDialogRef, MatSnackBar } from '@angular/material';
import { FuseConfirmDialogComponent } from '@fuse/components/confirm-dialog/confirm-dialog.component';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { fuseAnimations } from '@fuse/animations';
import { debounceTime, tap, switchMap, finalize } from 'rxjs/operators';
import { VentaShowComponent } from 'app/components/venta/venta-show/venta-show.component';
import { VentaFormComponent } from 'app/components/venta/venta-form/venta-form.component';
import { EntidadService } from 'app/services/entidad.service';
import { VentaService, DataService } from 'app/services/venta.service';
import { SedeService } from 'app/services/sede.service';
import { EntidadFormComponent } from 'app/components/entidad/entidad-form/entidad-form.component';
import { saveAs } from 'file-saver';
import { Utils } from 'app/services/utils';
import { VentaDowloandComponent } from 'app/components/venta/venta-dowloand/venta-dowloand.component';
import { format } from 'date-fns';
import { VentasDescargaComponent } from './ventas-descarga/ventas-descarga.component';
import { VentasPdfComponent } from './ventas-pdf/ventas-pdf.component';
import { Router } from '@angular/router';
import { ContactoShowComponent } from 'app/components/contacto/contacto-show/contacto-show.component';
import { DataStateChangeEventArgs } from '@syncfusion/ej2-grids';
import { Observable } from 'rxjs';
import { GridComponent } from '@syncfusion/ej2-angular-grids';

@Component({
  selector: 'app-ventas',
  templateUrl: './ventas.component.html',
  styleUrls: ['./ventas.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations
  // providers: [DataService]
})
export class VentasComponent implements OnInit {

  dialogRef: any;
  loadVenta = false;
  /* GRID */
  // dcVenta: string[] = ['cliente_entidad', 'iddocumentofiscal', 'numero', 'fechaemision', 'idestadodocumento', 'total', 'enviado', 'sunat', 'acciones'];
  // dsVenta = new MatTableDataSource();  
  // rLengthVenta = 0;
  // pSizeVenta = 20;
  // @ViewChild('pagVenta', { static: true }) pagVenta: MatPaginator;
  // @ViewChild('sortVenta', { static: true }) sortVenta: MatSort;
  /* GRID */

  /* BUSCARDOR PERSONA */
  searchResult: any[] = [];
  isLoadingSearch = false;
  /* BUSCARDOR PERSONA */

  /* FILTROS */
  filtros = false;
  idsede = new FormControl();
  // numero = new FormControl();  
  sedes: any[] = [];

  filterForm: FormGroup;
  searchForm: FormGroup;
  /* SEARCH */

  // public data: DataManager;
  @ViewChild('grid', { static: true }) public grid: GridComponent;

  public pageSettings = { pageSize: 20, pageSizes: [5, 10, 20, 50, 100] };
  public data: Observable<DataStateChangeEventArgs>; 

  constructor(
    private router: Router,
    private _matDialog: MatDialog,
    private _entidadService: EntidadService,
    private _ventaService: VentaService,
    private _sedeService: SedeService,
    private _utils: Utils,
    private snackBar: MatSnackBar,
    public service: DataService
  ) {
    this.idsede.setValue(this._entidadService.sedeDefault || '');
    this.data = service; 
  }

  ngOnInit(): void {
    this.searchForm = this.createSearchForm();
    this.filterForm = this.createFilterForm(); 
    // this.sortVenta.sortChange.subscribe(() => {
    //   this.pagVenta.pageIndex = 0;
    //   this.index();
    // });

    // this.pagVenta.page.subscribe(() => {
    //   this.index();
    // }); 
    this.searchForm.controls['iddocumentofiscal'].valueChanges
      .subscribe(data => {
        console.log('searchForm iddocumentofiscal', data);
        this.index();
      });

    this.filterForm.controls['iddocumentofiscal'].valueChanges
      .subscribe(data => {
        console.log('filterForm iddocumentofiscal', data);
        this.index();
      });

    this.filterForm.controls['idcliente'].valueChanges
      .pipe(
        debounceTime(300),
        tap(() => this.isLoadingSearch = true),
        switchMap(data => {

          if (data === '') {
            this.index();
          }

          if (data && typeof data === 'string') {
            const param = {
              page: 1,
              pageSize: 10,
              orderName: 'entidad',
              orderSort: 'asc',
              conRecurso: 'documento'
            };

            if (parseFloat(data) > 0) {
              param['numerodoc'] = data;
            } else {
              param['likeEntidad'] = data;
            }

            return this._entidadService.index(param)
              .pipe(
                finalize(() => this.isLoadingSearch = false),
              );
          } else {
            this.isLoadingSearch = false;
            return [];
          }
        })
      )
      .subscribe((data: any) => {
        this.searchResult = data;
      });

    this.index();
    this.indexSedes();
  }

  createSearchForm(): FormGroup {
    return new FormGroup({
      iddocumentofiscal: new FormControl(),
      serie: new FormControl(),
      numero: new FormControl()
    });
  }

  createFilterForm(): FormGroup {
    return new FormGroup({
      iddocumentofiscal: new FormControl(''),
      serie: new FormControl(''),
      numeroFrom: new FormControl(''),
      numeroTo: new FormControl(''),
      idcliente: new FormControl(''),
      fechaemisionFrom: new FormControl(''),
      fechaemisionTo: new FormControl('')
    });
  }

  index(state?: DataStateChangeEventArgs): void {
    let page = 1;
    let pageSize = 20;
    let orderName = 'idventa';
    let orderSort = 'desc';

    if (state) {
      console.log('state', state);
      page = (state.skip / state.take) + 1;
      pageSize = state.take;
      if (state.action && state.action['columnName']) {
        orderName = state.action['columnName'];
        orderSort = state.action['direction'] === 'Ascending' ? 'asc' : 'desc';
      }
    }

    const param = {
      page: page,
      pageSize: pageSize,
      orderName: orderName,
      orderSort: orderSort,
      conRecurso: 'sede,cliente.documento,docnegocio'
    };

    if (this.idsede.value) {
      param['idsede'] = this.idsede.value;
    }

    const searchRaw = this.searchForm.getRawValue();
    this.clean(searchRaw);

    Object.assign(param, searchRaw);

    const filterRaw = this.filterForm.getRawValue();
    this.clean(filterRaw);

    Object.assign(param, filterRaw);

    if (param['idcliente']) {
      param['idcliente'] = param['idcliente'].identidad;
    }

    if (param['fechaemisionFrom']) {
      param['fechaemisionFrom'] = format(param['fechaemisionFrom'], 'YYYY-MM-DD');
    }

    if (param['fechaemisionTo']) {
      param['fechaemisionTo'] = format(param['fechaemisionTo'], 'YYYY-MM-DD');
    }

    this.loadVenta = !state ? true : false;
    this.service.execute(param).subscribe(x => {
      this.loadVenta = false;
      this.service.next(x);
    });
  }

  // index(filterSearch?: boolean): void { 

  //   if (filterSearch) {
  //     this.pagVenta.pageIndex = 0;
  //   }

  //   const param = {
  //     page: this.pagVenta.pageSize ? (this.pagVenta.pageIndex + 1) : 1,
  //     pageSize: this.pagVenta.pageSize ? this.pagVenta.pageSize : this.pSizeVenta,
  //     orderName: this.sortVenta.active ? this.sortVenta.active : 'idventa',
  //     orderSort: this.sortVenta.direction ? this.sortVenta.direction : 'desc',
  //     conRecurso: 'sede,cliente.documento,docnegocio'
  //   };

  //   if (this.idsede.value) {
  //     param['idsede'] = this.idsede.value;
  //   }

  //   const searchRaw = this.searchForm.getRawValue();
  //   this.clean(searchRaw);

  //   Object.assign(param, searchRaw);

  //   const filterRaw = this.filterForm.getRawValue();
  //   this.clean(filterRaw);

  //   Object.assign(param, filterRaw);

  //   if (param['idcliente']) {
  //     param['idcliente'] = param['idcliente'].identidad;
  //   }

  //   if (param['fechaemisionFrom']) {
  //     param['fechaemisionFrom'] = format(param['fechaemisionFrom'], 'YYYY-MM-DD');
  //   }

  //   if (param['fechaemisionTo']) {
  //     param['fechaemisionTo'] = format(param['fechaemisionTo'], 'YYYY-MM-DD');
  //   } 

  //   this.loadVenta = true;
  //   this._ventaService.index(param)
  //     .subscribe((data: any) => { 
  //       this.dsVenta.data = data.data;
  //       this.loadVenta = false;
  //       this.rLengthVenta = data.total;
  //     }, error => { 
  //     });
  // }

  clean(obj: any): void {
    // https://stackoverrun.com/es/q/38562
    for (const propName in obj) {
      if (obj[propName] === null || obj[propName] === undefined || obj[propName] === '') {
        delete obj[propName];
      }
    }
  }

  showVenta(venta): void {
    this.dialogRef = this._matDialog.open(VentaShowComponent, {
      panelClass: 'venta-show-dialog',
      data: {
        idventa: venta.idventa
      }
    });

    this.dialogRef.afterClosed()
      .subscribe((response) => {
        if (!response) {
          return;
        }
      });
  }

  downloadVenta(): void {
    this.dialogRef = this._matDialog.open(VentaDowloandComponent, {
      panelClass: 'venta-download-dialog',
      data: {

      }
    });

    this.dialogRef.afterClosed()
      .subscribe((response) => {
        if (!response) {
          return;
        }
      });
  }

  newVenta(): void {
    this.dialogRef = this._matDialog.open(VentaFormComponent, {
      panelClass: 'venta-form-dialog',
      data: {
        action: 'new',
        fechaEmision: new Date()
      },
      autoFocus: false,
      disableClose: true
    });

    this.dialogRef.afterClosed()
      .subscribe((response) => {
        if (!response) {
          return;
        }

        this.index();
      });
  }

  descargar(): void {
    this.dialogRef = this._matDialog.open(VentasDescargaComponent, {
      panelClass: 'venta-descarga-dialog',
      data: {
        item: null
      },
      autoFocus: false
    });

    this.dialogRef.afterClosed()
      .subscribe(response => {
        if (!response) {
          return;
        }

        this.index();
      });
  }

  pdf(idventa): void {
    this.dialogRef = this._matDialog.open(VentasPdfComponent, {
      panelClass: 'venta-pdf-dialog',
      data: {
        idventa: idventa
      },
      autoFocus: false
    });

    this.dialogRef.afterClosed()
      .subscribe(response => {
        if (!response) {
          return;
        }

        this.index();
      });
  }

  anularVenta(venta: any): void {
    this.dialogRef = this._matDialog.open(FuseConfirmDialogComponent, {
      disableClose: false
    });
    this.dialogRef.componentInstance.confirmMessage = `Estas seguro que quieres anular ${venta.docnegocio.nombre} ${venta.serie} - ${venta.numero}?`;

    this.dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this._ventaService.anular(venta.idventa).subscribe(() => {
          this.snackBar.open(`${venta.docnegocio.nombre} ${venta.serie} - ${venta.numero} anulado.`, 'Cerrar');
          this.index();
        }, error => {
          const message = this._utils.convertError(error);
          this.snackBar.open(message, 'Cerrar', { panelClass: ['error-dialog'] });
        });
      }
      this.dialogRef = null;
    });

  }

  indexSedes(): void {
    const param = {
      orderName: 'nombre',
      orderSort: 'asc',
      comercial: '1'
    };

    this._sedeService.index(param)
      .subscribe((data: any) => {
        this.sedes = data.data;
      });
  }

  showEntidad(id): void {
    this.dialogRef = this._matDialog.open(ContactoShowComponent, {
      panelClass: 'contacto-show-dialog',
      data: {
        dialogTitle: 'Cliente',
        identidad: id
      }
    });

    this.dialogRef.afterClosed()
      .subscribe((response) => {
        if (!response) {
          return;
        }

        if (response === 'edit') {
          this.editEntidad(id);
        }

        if (response === 'refresh') {
          this.index();
        }
      });
  }

  editEntidad(id): void {
    this.dialogRef = this._matDialog.open(EntidadFormComponent, {
      panelClass: 'entidad-form-dialog',
      data: {
        action: 'edit',
        dialogTitle: 'Editar cliente',
        tipo: 'cliente',
        tabPaciente: false,
        identidad: id
      },
      autoFocus: false
    });

    this.dialogRef.afterClosed()
      .subscribe(response => {
        if (!response) {
          return;
        }
        this.index();
      });
  }

  downloadPdf(id: number): void {
    this._ventaService.show(id, { conRecurso: 'afiliado,docnegocio' })
      .subscribe((data: any) => {

        const param = {
          codCPE: data.data.docnegocio.codigosunat,
          numSerieCPE: data.data.serie,
          numCPE: data.data.numero,
          user: {
            username: `${data.data.afiliado.numerodoc}${data.data.afiliado.cpeuser}`,
            password: data.data.afiliado.cpepassword
          }
        };

        const namefile = `${data.data.afiliado.numerodoc}-${data.data.docnegocio.codigosunat}-${data.data.serie}-${data.data.numero}.pdf`;
        this._ventaService.pdfScontech(param, namefile)
          .subscribe(() => {

          }, (error) => {

          });
      }, (error) => {
      });
  }

  displaySearchEntidad(user?): string | null {
    const valor = user ? user.entidad : null;
    return valor;
  }

  download(formato): void {

    const param = {
      parametro: 'Hola mundo'
    };

    if (formato === 'pdf') {

      this._ventaService.exportPdf().subscribe((data) => {
        console.log('data pdf', data);
        saveAs(data, 'VentaPdf.pdf');
      }, (error) => {
        const message = this._utils.convertError(error);
        // swal('Upss!', message, 'error');
      });
    }

    if (formato === 'excel') {
      this._ventaService.exportExcel(param).subscribe((data) => {
        saveAs(data, 'VentaExcel.xlsx');
      }, (error) => {
        const message = this._utils.convertError(error);
        // swal('Upss!', message, 'error');
      });
    }
  }

  activarFiltro(): void {
    console.log(this.filtros);
    if (!this.filtros) {
      const iddocumentofiscal = this.searchForm.get('iddocumentofiscal').value;
      const serie = this.searchForm.get('serie').value;
      const numero = this.searchForm.get('numero').value;
      if (iddocumentofiscal || serie || numero) {
        this.searchForm.reset({}, { emitEvent: false });
        this.filterForm.get('iddocumentofiscal').setValue(iddocumentofiscal, { emitEvent: false });
        this.filterForm.get('serie').setValue(serie);
        this.filterForm.get('numeroFrom').setValue(numero);
        this.filterForm.get('numeroTo').setValue(numero);
      }
    }

    if (this.filtros) {
      const iddocumentofiscal = this.filterForm.get('iddocumentofiscal').value;
      const serie = this.filterForm.get('serie').value;
      const numeroFrom = this.filterForm.get('numeroFrom').value;
      const numeroTo = this.filterForm.get('numeroTo').value;
      const idcliente = this.filterForm.get('idcliente').value;
      const fechaemisionFrom = this.filterForm.get('fechaemisionFrom').value;
      const fechaemisionTo = this.filterForm.get('fechaemisionTo').value;
      if (iddocumentofiscal || serie || numeroFrom || numeroTo || idcliente || fechaemisionFrom || fechaemisionTo) {
        this.filterForm.reset({}, { emitEvent: false });
        this.searchForm.get('iddocumentofiscal').setValue(iddocumentofiscal, { emitEvent: false });
        this.searchForm.get('serie').setValue(serie);
        this.searchForm.get('numero').setValue(numeroFrom);

        if (idcliente || (numeroTo && numeroTo !== numeroFrom) || fechaemisionFrom || fechaemisionTo) {
          this.index();
        }
      }
    }

    this.filtros = !this.filtros;
  }

  nuevoComprobante(item: any, documento?: any): void {
    if (!documento) {
      switch (item.iddocumentofiscal) {
        case 1:
          documento = 'Factura';
          break;
        case 2:
          documento = 'Boletadeventa';
          break;
        case 13:
          documento = 'Notadecredito';
          break;
        case 10:
          documento = 'Notadedebito';
          break;
        default:
          break;
      }
    }

    this.router.navigate(['/ventas/nuevo/' + documento, { venta: item.idventa }]);
  }

}
